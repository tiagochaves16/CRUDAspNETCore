﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Produtos.Data.Migrations
{
    public partial class produtos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Produtos",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    NomeProduto = table.Column<string>(nullable: false),
                    DesProduto = table.Column<string>(nullable: false),
                    CatProduto = table.Column<string>(nullable: false),
                    ValorProduto = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Produtos", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Produtos");
        }
    }
}
