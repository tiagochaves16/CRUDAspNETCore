﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Produtos.Models
{
    public class Produto
    {
        public Guid Id { get; set; }
        
        [Required]
        public string NomeProduto { get; set; }
        [Required]
        public string DesProduto { get; set; }
        [Required]
        public string CatProduto { get; set; }
        [Required]
        public int ValorProduto { get; set; }
        public Produto()
        {
            Id = Guid.NewGuid();
        }
    }
}
